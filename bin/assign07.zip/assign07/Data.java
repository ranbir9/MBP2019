package assign07;

public @interface Data {

}
