package comprehensive;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Driver {
    public static void main(String[] args) {
        if (args.length < 1) {
            System.err.println("Please provide an input file");
            System.exit(1);
        }

        String inputFile = args[0];
        ForestDisjointSet<String> disjointSet = new ForestDisjointSet<>();

        try {
            BufferedReader reader = new BufferedReader(new FileReader(inputFile));
            String line;
            ArrayList<String> elements = new ArrayList<>();
            ArrayList<String[]> edges = new ArrayList<>();
            ArrayList<String[]> queries = new ArrayList<>();

            //Read elements
            while ((line = reader.readLine()) != null && !line.isBlank()) {
                elements.add(line);
            }

            //Read edges
            while ((line = reader.readLine()) != null && !line.isBlank()) {
                edges.add(line.split(" "));
            }

            // Read queries
            while ((line = reader.readLine()) != null && !line.isBlank()) {
                queries.add(line.split(" "));
            }

            reader.close();

            //Make sets for each element
            for (String element : elements) {
                disjointSet.makeSet(element);
            }

            // Perform union operations for edges
            for (String[] edge : edges) {
                disjointSet.union(edge[0], edge[1]);
            }

            // Process queries and print results
            for (String[] query : queries) {
                if (disjointSet.getRepresentative(query[0]).equals(disjointSet.getRepresentative(query[1]))) {
                    System.out.println("connected");
                } else {
                    System.out.println("not connected");
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading input file: " + e.getMessage());
        }
    }
}
