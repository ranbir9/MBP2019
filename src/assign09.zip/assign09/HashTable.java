package assign09;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.math.*;

public class HashTable<K, V> implements Map<K, V> {
    private static final MapEntry TOMBSTONE = new MapEntry<>(null, null);
    //Backing arraylist
    //MapEntry<K, V>[] table = new MapEntry[1];
     ArrayList<MapEntry<K, V>> table;
    private int size = 0;
    private int coll = 0; 

    public HashTable() {
        //int capacity = findNextPrime(13); // A reasonably large, prime initial capacity
        int primeCapacity = getPrime(3); 
        //table = new ArrayList<>(primeCapacity);
        table = new ArrayList<>(primeCapacity);

        //add elements
        for(int i = 0; i < primeCapacity; i++){
            table.add(null); 
        }
    }   

    // O(Table Length)
    @Override
    public void clear() {
        ArrayList<MapEntry<K, V>> newTable = new ArrayList<>(table.size()); 
        for(int i = 0; i < table.size(); i++){
            newTable.add(null); 
        }
        table = newTable; 
        size = 0; 
    }


    //O(1) - chaining and quadratic probing
    @Override
    public boolean containsKey(K key) {
        if (key == null)
            return false;

        int hash = Compress(key.hashCode());

        for (int i = 0; i < table.size(); i++) {
            int index = Compress((hash + i * i));

            if (table.get(index) == null) {
                return false;
            }

            if (table.get(index).getKey() != null && table.get(index).getKey().equals(key)) {
                return true;
            }
        }
        return false;
    }

    //O(Table Length)
    @Override
    public boolean containsValue(V value) {
        if (value == null) {
            return false;
        }

        for (int i = 0; i < table.size(); i++) {
            if (table.get(i) != null && table.get(i) != TOMBSTONE) {
                if (table.get(i).getValue().equals(value))
                    return true;
            }
        }
        return false;
    }

    //O(Table Length)
    @Override
    public List<MapEntry<K,V>> entries() {
        List<MapEntry<K, V>> list = new ArrayList<>();
        for (int i = 0; i < table.size(); i++) {
            if(!(table.get(i) == null || table.get(i) == TOMBSTONE))
                list.add(table.get(i));
        }

        return list;
    }

    //O(1)
    @Override
    public V get(K key) {
        int hash = key.hashCode();

        if (containsKey(key)) {
            for (int i = 0; i < table.size(); i++) {
                int index = Compress((hash + i * i));
                if(table.get(index) == null)
                    return null; 

                if (table.get(index).getKey() != null && table.get(index).getKey().equals(key)) {
                    return table.get(index).getValue();
                }
            }
        }
        return null;
    }

    //O(1)
    @Override
    public boolean isEmpty() {
        return size == 0; 
    }

    //O(1)
    @Override
    public V put(K key, V value) {
        if (key == null || value == null) {
            throw new IllegalArgumentException("Key or Value or Both are null");
        }

        // Check the load factor and resize the table if necessary
        // int nextSize = size() + 1; 
        // int tableSize = table.size(); 
        // int l = (nextSize / tableSize);
        // double lambda = (nextSize / tableSize);
        double lambda = ((double) size+1) / table.size();
        if (lambda > 0.5) {
            resize();
        }

        int hash = Compress(key.hashCode());

        V prev;
        for (int i = 0; i < table.size(); i++) {
            int index = Compress(hash + i * i);
            if(i != 0){
                coll++; 
            }

            //add key-value if index is null or previously deleted or if key already exists update oldvalue to new value 
            if (table.get(index) == null || table.get(index) == TOMBSTONE || table.get(index).getKey().equals(key)) {
                 //previous value at index, null for nothing there before
                if(table.get(index) == null || table.get(index) == TOMBSTONE){
                    prev = null; 
                    size++; 
                } else {
                    prev = table.get(index).getValue(); 
                }

                // Place the new entry at the index
                table.set(index, new MapEntry<>(key, value));

                if (table.get(index) == null || table.get(index) == TOMBSTONE) {
                    //size++;
                }
                return prev;
            }
        }
        return null; 
    }

    //Helper Method - find next largest prime 
    private int getPrime(int size){
        BigInteger bi1 = BigInteger.valueOf(size); 
        bi1 = bi1.nextProbablePrime(); //find next prime number after min size
        int nextPrimeInt = bi1.intValue(); 
        return nextPrimeInt; 
    }

    //Helper Method - resize table * 2 and find next biggest prime 
    private void resize() {
        ArrayList<MapEntry<K,V>> oldTable = table;
        int newSize = getPrime(oldTable.size() * 2); 
        table = new ArrayList<>(newSize);
        for(int i = 0; i < newSize; i++){
            table.add(null); 
        }
        size = 0;

        for (MapEntry<K, V> entry : oldTable) {
            if (entry != null && entry != TOMBSTONE) {
                put(entry.getKey(), entry.getValue());
            }
        }
    }

    //O(1) - 
    @Override
    public V remove(K key) {
        if (key == null) {
            throw new IllegalArgumentException("Key is NULL");
        }
        int hash = Compress(key.hashCode());

        for (int i = 0; i < table.size(); i++) {
            int index = Compress((hash + i * i));
            if (table.get(index) == null) {// probing never made it this far, doesn't exist beyond
                return null;
            }

            if (table.get(index).getKey() != null && table.get(index).getKey().equals(key)) {
                V prev = table.get(index).getValue();

                // Place a tombstone at the slot where the key was found
                table.set(index, TOMBSTONE);
                size--;
                return prev;
            }
        }
        // Key not found or reached the end of probing attempts
        return null;
    }

    //O(1)
    @Override
    public int size() {
        return size;

    }

    //Helper method - get a slot value using hashCode
    // public int Compress(int hashCode) {
    //     int index = hashCode % table.size();
    //     return index;
    // }
    public int Compress(int hashCode) {
        int index = hashCode % table.size();
        if (index < 0) {
            index += table.size();
        }
        return index;
    }


    public String toString() {
        String str = "[ ";
        for (int i = 0; i < table.size(); i++) {
            if (table.get(i) == null || table.get(i) == TOMBSTONE) {
                str += "null ";
            } else {
                str += table.get(i).getKey() + ": ";
                str += table.get(i).getValue();
            }
            if (i != table.size() - 1)
                str += ", ";
        }
        return str += "]";
    }

    public int coll(){
        return coll; 
    }

    public static void main(String args[]) {
        // MapEntry<Integer, String> map = new MapEntry<Integer,String>(1, "Ven");
        //HashTable<Integer, String> table = new HashTable<>();
        // table.put(1, "Ven");
        // table.put(2, "Ken");
        // System.out.println(table.toString());
        HashTable<String, Integer> table = new HashTable<>();
        System.out.println(table.size);
        System.out.println("Prev value at index: " + table.put("Ven", 100));
        System.out.println(table.toString());
        System.out.println("Prev value at index: " + table.put("Ven", 1));
        System.out.println(table.toString());

        System.out.println(table.containsKey("Ven"));
        System.out.println("Removed Value: " + table.remove("Ven"));
        System.out.println(table.containsKey("Ven"));
        System.out.println(table.toString());

        // System.out.println("Removed Value: " + table.remove("Fake"));
        table.put("Wow", 10);
        System.out.println(table.toString());
        System.out.println("Contains value 10: " + table.containsValue(10));
        System.out.println("Contains value 11: " + table.containsValue(11));
        System.out.println("get(K): " + table.get("Wow"));
        System.out.println("get(K): " + table.get("to"));
        System.out.println("size: " + table.size() + " Table: " + table.toString());
        table.clear();
        System.out.println(table.toString());

        String hash1 = "2"; 
        String hash2 = "128";
        String hash3 = "146";  
        System.out.println(table.Compress(hash1.hashCode()) + " " + table.Compress(hash2.hashCode()) + " " + table.Compress(hash3.hashCode()));
        table.put("2", 0); 
        
        System.out.println(table.toString());
        table.put("128", 1); 
        System.out.println(table.toString());
        table.put("146", 2); 
        System.out.println(table.toString());
        table.put("164", 3); 
        System.out.println(table.toString());
        System.out.println("Size: " + table.size);

        System.out.println("coll: " + table.coll());

        // System.out.println("Contains 164: " + table.containsKey("164"));
        // System.out.println("Value of 164: " + table.get("164"));
        // //System.out.println("Remove 164: " + table.remove("164"));
        // System.out.println(table.toString());

        // BigInteger bi1, bi2; 
        // bi1 = new BigInteger("73"); 
        // bi1 = bi1.nextProbablePrime(); 
        // System.out.println(bi1.toString());
        // System.out.println(bi1.intValue());

        // table.clear();
        // System.out.println("After clear: " + table.toString());
    }

}
