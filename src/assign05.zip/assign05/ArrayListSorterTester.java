package assign05;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ArrayListSorterTester {

    private ArrayList<Integer> list;

    @BeforeEach
    public void setUp() {
        list = new ArrayList<>();
        Random rand = new Random();
        for (int i = 0; i < 10; i++) {
            list.add(rand.nextInt(100));
        }
    }

    

    @Test
    public void testMergesort() {
        System.out.println(list.toString());
        ArrayList<Integer> sortedList = new ArrayList<>(list);
        //System.out.println(sortedList.toString());
        ArrayListSorter.mergesort(sortedList);
        System.out.println(sortedList.toString());

    }

    @Test
    public void testQuicksort() {
        System.out.println(list.toString());
        ArrayList<Integer> sortedList = new ArrayList<>(list);
        //System.out.println(sortedList.toString());
        ArrayListSorter.quicksort(sortedList);
        System.out.println(sortedList.toString());

    }

}