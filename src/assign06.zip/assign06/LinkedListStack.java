package assign06;

import java.util.NoSuchElementException;

public class LinkedListStack<E> implements Stack<E> {

    private SinglyLinkedList<E> list;

    public LinkedListStack() {
        list = new SinglyLinkedList<E>();
    }

    public void clear() {
        list.clear();
    }

    public boolean isEmpty() {
        return list.isEmpty();
    }

    public E peek() throws NoSuchElementException {
        if (isEmpty())
            throw new NoSuchElementException();
        return list.getFirst();
    }

    public E pop() throws NoSuchElementException {
        if (isEmpty())
            throw new NoSuchElementException();
        return list.deleteFirst();
    }

    public void push(E element) {
        list.insertFirst(element);
    }

    public int size() {
        return list.size();
    }

    // public static void main (String[] args){
    //     LinkedListStack<Integer> list = new LinkedListStack<>(); 
    //     list.push(20);
    //     list.push(30);
    //     list.push(40);
    //     list.push(10);
    //     System.out.println("peek: " + list.peek()); //show top of stack 
    //     list.pop(); 
    //     System.out.println("peek after pop(): " + list.peek());

    //     System.out.println("isEmpty: " + list.isEmpty());
    //     list.clear();
    //     System.out.println("isEmpty after clear(): " + list.isEmpty());


    // }
}
